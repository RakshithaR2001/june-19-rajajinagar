package com.xworkz.rakshitha.app;

public class Mechanic {

	
	public String qualification = "diploma";
	public int experience = 3;
	
	
	public void repair()
	{
		System.out.println("invoking repair in mechanic");
	}
	public void washingVehicle()
	{
		System.out.println("invoking main in mechanic");
	}
	
}
