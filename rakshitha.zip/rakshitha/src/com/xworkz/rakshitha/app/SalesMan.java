package com.xworkz.rakshitha.app;

public class SalesMan {
	
	public String name = "ranjith";
	public  double salary =18000;
	
	
	public void productSale()
	{
		System.out.println("invoking productSale in salesMan");
		
	}
	public void feedBack()
	{
		System.out.println("invoking feedBack in salesMan");
	}

}
