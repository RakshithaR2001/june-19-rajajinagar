package com.xworkz.rakshitha.app;

public class Patient {
	
	public String disease = "fever";
	public int checkUpBill =  2000;
	
	public void bedRest()
	{
		System.out.println("invoking bedRest in patient");
	}
	public void recovery()
	{
		System.out.println("invoking recovery in patient");
	}
	

}
