package com.xworkz.rakshitha.app;

public class Cook {
	public String name = "anand";
	public String item ="Dosa";
	
	public void prepareFood()
	{
		System.out.println("invoking prepareFood in cook");
	}
	
	public void serveFood()
	{
		System.out.println("invoking serveFood in cook");
	}

	
}
