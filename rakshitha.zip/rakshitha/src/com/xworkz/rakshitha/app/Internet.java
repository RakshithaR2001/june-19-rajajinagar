package com.xworkz.rakshitha.app;

public class Internet {
	
	public String internetName = "wi-fi";
	public int  speed = 300;
	
	
	public void search()
	{
		System.out.println("invoking search in internet");
	}
	public void connect()
	{
		System.out.println("invoking connect in internet");
	}
         
}
